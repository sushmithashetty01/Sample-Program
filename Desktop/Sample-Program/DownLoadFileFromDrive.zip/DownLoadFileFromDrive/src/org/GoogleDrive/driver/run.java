package org.GoogleDrive.driver;

import org.openqa.selenium.support.ui.WebDriverWait;

public class run {
	public static void main(String args[]) {
		main main = new main();
		
		//Test to browser,Login and quite driver methods
		try {
			main.getBrowser();
			main.login();
			main.quiteDriver();
		
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
