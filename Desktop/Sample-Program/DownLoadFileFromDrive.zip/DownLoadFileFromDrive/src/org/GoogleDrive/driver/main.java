package org.GoogleDrive.driver;
import java.util.concurrent.TimeUnit;
import org.GoogleDrive.utils.constantsFile;
import org.GoogleDrive.utils.readproperties;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class main {

	WebDriver driver;
	@BeforeTest
	public void getBrowser() {
		
		//Initailize chrome driver for google chrome
		System.setProperty(constantsFile.driverProperties, constantsFile.ChromeDriverpath);
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		capabilities.setCapability(CapabilityType.BROWSER_NAME, "Chrome");
		capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		driver = new ChromeDriver(capabilities);
		driver.manage().window().maximize();
		
		//Launch google drive URL which is stored in config.properties file
		driver.navigate().to((String) readproperties.readObjProperties("DRIVEURL"));
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
		
        //Verify the title of the page when directed to the URL
		Assert.assertEquals("Google Drive: Free Cloud Storage for Personal Use", driver.getTitle());

	}
       
	@Test
	public void login() throws InterruptedException {
		Thread.sleep(2000);
		//Webelement to Go to google drive icon which directs to login page 
		WebElement mainButton = driver.findElement(By.xpath(readproperties.readORProperties("mainButtonCLick")));
		mainButton.click();
		
		//Enter Username
		WebElement userName = driver.findElement(By.id("identifierId"));
		userName.sendKeys(readproperties.readORProperties("UserName").trim());
		driver.findElement(By.xpath(readproperties.readORProperties("nextButton"))).click();
		Thread.sleep(2000);
		
		//Enter Password
		WebElement passWord = driver.findElement(By.name("password"));
		passWord.sendKeys(readproperties.readORProperties("PassWord").trim());
		driver.findElement(By.xpath("//*[@id=\"passwordNext\"]/span/span")).click();

          //download files to local disk by right clicking
			Actions act=new Actions(driver);
			WebDriverWait wait = new WebDriverWait(driver,30);
			act.contextClick(driver.findElement(By.xpath("//div[contains(text(),'dummy')]"))).sendKeys(Keys.ARROW_DOWN).
			sendKeys(Keys.ARROW_DOWN)
			.sendKeys(Keys.ARROW_DOWN)
			.sendKeys(Keys.ARROW_DOWN)
			.sendKeys(Keys.ARROW_DOWN)
			.sendKeys(Keys.ARROW_DOWN)
			.sendKeys(Keys.ARROW_DOWN)
			.sendKeys(Keys.ARROW_DOWN) 
			.sendKeys(Keys.ARROW_DOWN)
			.sendKeys(Keys.ARROW_DOWN)
			.sendKeys(Keys.ARROW_DOWN)
			.sendKeys(Keys.ARROW_DOWN)
			.sendKeys(Keys.RETURN).build().perform();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			
		}
//	
//		}
	
     //Logout from the google drive
	@AfterTest
	public void quiteDriver() {
		WebElement Selectsignout = driver.findElement(By.xpath(".//*[@class='gb_D gb_Oa gb_i']"));
		Selectsignout.click();
		WebElement SignOut = driver.findElement(By.xpath(".//*[text()='Sign out']"));
		SignOut.click();
		driver.quit();
	}
}
