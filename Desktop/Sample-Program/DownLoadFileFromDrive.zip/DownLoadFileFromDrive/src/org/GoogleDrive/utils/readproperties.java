package org.GoogleDrive.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

//class to read common files
public class readproperties {
	
	public static Object readObjProperties(String key) {
		
		Object	obj = new Object();
		File file = new File(constantsFile.configProperties);
		try {
			FileInputStream readFile = new FileInputStream(file);
			Properties prop = new Properties();
			prop.load(readFile);
			obj = prop.get(key);
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
		
			e.printStackTrace();
		}
		return obj;	
	}
	public static String readORProperties(String key) {
			String propval = null;
		File file = new File(constantsFile.orProperties);
		try {
			FileInputStream orprop = new FileInputStream(file);
			Properties prop = new Properties();
			prop.load(orprop);	
			propval = prop.getProperty(key);
			
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}	
		return propval;
		
	}

}
