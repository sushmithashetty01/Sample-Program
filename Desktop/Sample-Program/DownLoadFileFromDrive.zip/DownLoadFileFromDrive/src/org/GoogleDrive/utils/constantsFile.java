package org.GoogleDrive.utils;

//class to use common file
public class constantsFile {

	public static final String ChromeDriverpath=System.getProperty("user.dir")+"//chromedriver.exe";
	public static final String driverProperties = "webdriver.chrome.driver";
	public static final String configProperties = System.getProperty("user.dir")+ "//config//config.properties";
	public static final String orProperties = System.getProperty("user.dir")+"//config//OR.properties";
}
